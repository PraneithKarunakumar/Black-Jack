package coe318.lab5;

public class Card implements Comparable {
  //Symbolic constants

  public static final int CLUB = 0;
  public static final int DIAMOND = 1;
  public static final int HEART = 2;
  public static final int SPADE = 3;

  /**
   * Construct a card of the given rank, suit and whether it is faceup or
   * facedown. The rank is an integer from 2 to 14. Numbered cards (2 to 10)
   * have a rank equal to their number. Jack, Queen, King and Ace have the ranks
   * 11, 12, 13, and 14 respectively. The suit is an integer from 0 to 3 for
   * Clubs, Diamonds, Hearts and Spades respectively.
   *
   * @param rank
   * @param suit
   * @param faceUp
   */
  private int Cardrank;
  private int Cardsuit;
  private boolean Cardfaceup;
  public Card(int rank, int suit, boolean faceUp) {
    Cardrank= rank;
    Cardsuit=suit;
    Cardfaceup=faceUp;
  }

  /**
   * @return the faceUp
   */
  public boolean isFaceUp() {
    return Cardfaceup; //FIX THIS
  }

  /**
   * @param faceUp the faceUp to set
   */
  public void setFaceUp(boolean faceUp) {
    Cardfaceup=faceUp;
  }

  /**
   * @return the rank
   */
  public int getRank() {
    return Cardrank; //FIX THIS
  }

  /**
   * @return the suit
   */
  public int getSuit() {
    return Cardsuit;//FIX THIS
  }

  @Override
  public boolean equals(Object ob) {
    if (!(ob instanceof Card)) {
      return false;
    }
    Card c = (Card) ob;
    if(c.getSuit()!=this.getSuit() && c.getRank()!=this.getRank()){
        return false;
    }
    else{
        return true; //FIX THIS
    }
  }

  @Override
  public int hashCode() {//DO NOT MODIFY
    int hash = 7;
    hash = 31 * hash + this.getRank();
    hash = 31 * hash + this.getSuit();
    return hash;
  }

  @Override
  public int compareTo(Object obj) {//DO NOT MODIFY
    return compareTo((Card) obj);
  }

  public int compareTo(Card c) {
    if(this.getRank()< c.getRank() || this.getRank() < c.getRank()){
        return -1;
    }
    if( this.getRank()> c.getRank() || this.getSuit()> c.getSuit()){
        return 1;
    }
    else{
        return 0;
    }
  }

  /**
   * Return the rank as a String. For example, the 3 of Hearts produces the
   * String "3". The King of Diamonds produces the String "King".
   *
   * @return the rank String
   */
  public String getRankString() {
    if(this.getRank() ==11){
        return "JACK";
    }
    else if(this.getRank() ==12){
        return "QUEEN";
    }
    else if(this.getRank() ==13){
        return "KING" ;
    }
    else if(this.getRank() ==14){
        return "ACE";
    }
    else{
        return Integer.toString(this.getRank());
    }
  }

  /**
   * Return the suit as a String: "Clubs", "Diamonds", "Hearts" or "Spades".
   *
   * @return the suit String
   */
  public String getSuitString() {
    if(this.getSuit() ==0){
        return "CLUBS";
    }
    else if(this.getSuit() ==1){
        return "DIAMONDS";
    }
    else if(this.getSuit() ==2){
        return "HEARTS" ;
    }
    else{
        return "SPADES";
    }
  }

  /**
   * Return "?" if the card is facedown; otherwise, the rank and suit of the
   * card.
   *
   * @return the String representation
   */
  @Override
  public String toString() {
      if(this.isFaceUp()){
          return(this.getRankString() + " of " + this.getSuitString());
      }
      return "?" ;
  }
  

  public static void main(String[] args) {
    //Create 5 of clubs
    Card club5 = new Card(5, 0, true);
    System.out.println("club5: " + club5);
    Card spadeAce = new Card(14, SPADE, true);
    System.out.println("spadeAce: " + spadeAce);
    System.out.println("club5 compareTo spadeAce: "
            + club5.compareTo(spadeAce));
    System.out.println("club5 compareTo club5: "
            + club5.compareTo(club5));
    System.out.println("club5 equals spadeAce: "
            + club5.equals(spadeAce));
    System.out.println("club5 equals club5: "
            + club5.equals(club5));
  }
}
